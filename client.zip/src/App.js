// import './App.css';
// import Home from './Components/Home';
// import {Routes,Route} from 'react-router-dom'
// // import Login from './Components/Form/Login';
// // import Signup from './Components/Form/Signup';
// // import IndividualVideo from './Components/IndividualVideo';
// function App() {
//   return (
//     <div className="App">
//      <Routes>
//       <Route exact path='/' element={<Home/>}></Route>
//       {/* <Route exact path='/IndividualVideo' element={<IndividualVideo/>}></Route> */}
//       {/* <Route exact path='/' element={<Signup/>}></Route> */}
//       {/* <Route exact path='/Login' element={<Login/>}></Route>     */}
//      </Routes>
//     </div>
//   );
// }

// export default App;















import './App.css';
import Home from './Components/Home';
import {Routes,Route} from 'react-router-dom'
import Login from './Components/Form/Login'
import Signup from './Components/Form/Signup'
import Alluserdetails from './Components/Alluserdetailes'
import IndividualVideo from './Components/IndividualVideo';
import GamingVideos from './Components/GamingVideos';
import SavedVideos from './Components/SavedVideos'

function App() {
  return (
    <div className="App">
     <Routes>
      <Route exact path='/' element={<Home/>}></Route> 
      <Route exact path='/video/:id' element={<IndividualVideo/>}></Route>
    <Route exact path='/signup' element={<Signup/>}></Route> 
      <Route exact path='/auth' element={<Login/>}></Route>    
      <Route exact path='/registered-users' element={<Alluserdetails/>}></Route>    
      <Route exact path="/gaming" element={<GamingVideos />}></Route>
      <Route exact path="/saved" element={<SavedVideos />}></Route>
 
     </Routes>
    </div>
  );
}

export default App;
