export const server = `https://synergy-watch-server.onrender.com`;
// https://synergy-watch-server.onrender.com

const apilist = {
  
    login: `${server}/login`,
    signup: `${server}/signup`,
    individualvideo: `${server}/individualvideo/`,
    trendingvideos: `${server}/trendingvideos`,
    gamingvideos: `${server}/gamingvideos`,
    savedvideos : `${server}/savedvideos`,
        
}
export default apilist;