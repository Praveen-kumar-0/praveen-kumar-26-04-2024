import React from 'react'
import 'remixicon/fonts/remixicon.css'
import'../Components/Sidebar.css'
import { Link } from 'react-router-dom'
import Cookies from "js-cookie";
import { useNavigate } from "react-router-dom";

function Sidebar() {
  const navigate = useNavigate();

  const handleLogout = (e) => {
    e.preventDefault();
    Cookies.remove('jwtAuth');
    navigate("/auth");
  }
  return (
    <div>
      <section className='sidebar_component sticky-top'>
        <div className='container-fluid pl-5 pt-5 sidebar-text'>
            <div className='sidebar_content'>
            <p className='side-title'><i class="ri-home-8-fill pr-3 "></i>  Home</p>
            </div>
            <div className='sidebar_content'>
            <p className='side-title'><i class="ri-discord-fill pr-3"></i> Gaming</p>
            </div>
            <div className='sidebar_content'>
            <p className='side-title'><i class="ri-fire-fill pr-3"></i> Trending</p>
            </div>
            <div className='sidebar_content'>
            <p className='side-title'><i class="ri-save-fill pr-3" ></i>Saved</p>
            </div>
        </div>
        <div className='btn' onClick={handleLogout}>
        <button className='logout-btn'>
          <Link to='/login'>
            <span className="logout-button" style={{color: `#000000`}}>Logout</span>
          </Link>
        </button>
      </div>
      </section>

    </div>

  )
}

export default Sidebar
