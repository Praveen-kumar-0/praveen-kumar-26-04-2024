import {  useEffect } from "react";
import React from "react";
import axios from "axios";

const SavedVideos = () => {
    const getSavedVideos = async () => {
      
        // 
    try {
      const response = await axios.get(`http://localhost:5555/savedvideos`);
      console.log(response.data);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    getSavedVideos();
  }, []);

  return <div></div>;
};

export default SavedVideos;
