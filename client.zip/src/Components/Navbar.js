import React from 'react';
import './Navbar.css';


const Navbar = () => {

  return (
    <div>
      <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <img class="img" src='https://www.static-contents.youth4work.com/y4w/Images/CompColleges/20230613122559.png?v=20230613122559%27'></img>
  <a class="navbar-brand" href="#">Synergy watch</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse " id="navbarNav" >
    <ul class="navbar-nav">
      <li class="nav-item ">
        <a class="nav-link" href="#">Home </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Features</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Pricing</a>
      </li>
      
    </ul>
  </div>
</nav>
    </div>
  )
}

export default Navbar
